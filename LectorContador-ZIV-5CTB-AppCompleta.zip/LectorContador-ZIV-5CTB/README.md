# Lector de contador (Android)

App Android (Kotlin + Jetpack Compose) que lee contadores eléctricos a través de una **sonda óptica USB**. Soporta IEC 62056-21 modo C, IEC 870-5-102 y un perfil **DLMS/COSEM para ZIV 5CTB-3AB-M**.

## Funciones
- **Leer y guardar**: lectura puntual (energía activa total, **hasta 6 periodos P1–P6**, potencia, tensión, intensidad) que se guarda en el histórico. Solo se muestran los periodos que el contador devuelve (2.0TD: P1–P3; 3.0TD/6.1TD: P1–P6).
- **Tres tipos de lectura** (botones *Consumo*, *FV* y *Todo*): el contador devuelve siempre todos sus registros; el botón elige qué se muestra y se guarda en detalle.
  - **Consumo**: energía activa importada (1.x.x), reactiva importada (3.x.x), instantáneos (tensión, intensidad…) e identificadores.
  - **FV**: energía y potencia activa/reactiva exportadas (2.x.x, 4.x.x: `2.8.0` total, `2.8.1`…`2.8.6` por periodo, `2.7.0` potencia), más instantáneos e identificadores. Si el contador no los devuelve, la app lo indica.
  - **Todo**: todos los códigos OBIS, también los no clasificados.
- **Todos los valores de cada línea**: si una línea trae varios paréntesis (p. ej. máxima demanda con su fecha, `1.6.1(02.5*kW)(2610011500)`), se conservan todos. Los códigos conocidos se muestran con su descripción en castellano.
- **Modo en vivo**: lecturas repetidas cada 10/30/60 s sin guardarlas. Se detiene solo tras 3 errores seguidos.
- **Histórico**: lista de lecturas y gráfica de consumo diario (últimos 14 días).
- **Exportar CSV** para Excel en español (separador `;`, coma decimal). Se comparten dos archivos: `lecturas_contador_*.csv` (resumen: total, `p1_kwh`…`p6_kwh`, instantáneos y energía/potencia FV exportada) y `obis_completo_*.csv` (una fila por código OBIS guardado, con grupo, descripción, valor, unidad y datos adicionales). El histórico guardado con la versión anterior (3 periodos) se sigue leyendo.
- **Acceso rápido a la configuración**: tarjeta con la foto del contador ZIV 5CTB-3AB-M arriba en la pestaña Lectura; al tocarla se abre **Ajustes**. La foto está en `app/src/main/res/drawable-nodpi/meter_photo.jpg`.
- Interfaz íntegramente en castellano.
- Ver todos los registros OBIS que devuelve el contador (útil para depurar).

- **Diagnóstico**: para contadores de protocolo desconocido. Prueba 300/1200/2400/4800/9600 baud en 7E1 y 8N1, envía solo la petición de lectura `/?!` y muestra los bytes recibidos (ASCII y hex). El informe se puede compartir.

## Cómo abrirlo
1. Android Studio (Ladybug o posterior) → *Open* → carpeta `LectorContador`.
2. Deja que sincronice Gradle (necesita internet; la librería USB viene de JitPack).
3. Conecta el móvil con depuración USB y pulsa *Run*.
4. Los tests del protocolo están en `app/src/test` (`./gradlew test` o clic derecho → *Run*).

## Si Android Studio no abre o sincroniza el proyecto
- Abre la carpeta que contiene directamente `settings.gradle.kts` (no la subcarpeta `app`).
- Incluye `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.9), que Android Studio usa para descargar Gradle. Si ofrece «actualizar/crear el Gradle wrapper», acepta.
- Si algo falla, copia el texto completo del error de la pestaña **Build** (abajo) para poder corregirlo.

## Obtener el APK sin Android Studio (GitHub Actions)
1. Crea un repositorio en https://github.com/new y sube todo el contenido de esta carpeta (incluida `.github`).
2. En la pestaña **Actions** se ejecuta «Build APK» (o lánzalo con *Run workflow*).
3. Al terminar, entra en la ejecución y descarga `LectorContador-debug-apk` desde **Artifacts**. Descomprime el ZIP para obtener `app-debug.apk`.

## Uso
1. Conecta la sonda al móvil con un adaptador **USB OTG**. Android pedirá permiso USB.
2. Coloca la sonda sobre el puerto óptico del contador (imán/alineada con el LED).
3. Pulsa **Consumo**, **FV** o **Todo** para leer y guardar.

## Cómo funciona el protocolo
1. Envía `/?!\r\n` a 300 baud, 7E1.
2. El contador responde `/XXXZ<identificación>`; `Z` es la velocidad propuesta (5 = 9600).
3. La app envía `ACK 0 Z 0 \r\n` y cambia a esa velocidad.
4. Recibe `STX <líneas OBIS> ! ETX BCC`, comprueba el BCC y lee los registros.

Registros que interpreta: `1.8.0` (total), `1.8.1` … `1.8.6` (periodos P1–P6), `1.7.0` (potencia), `32.7.0` (tensión), `31.7.0` (intensidad), `0.0.0` (nº de serie). Convierte W/Wh a kW/kWh automáticamente.

## ZIV 5CTB-3AB-M (DLMS/COSEM)

El modelo de la foto es un ZIV **5CTB-3AB-M**. El soporte añadido usa el puerto óptico en modo E y después DLMS/COSEM sobre HDLC. El perfil lee, cuando están disponibles, energía consumida `1.18.0` y `1.18.1…1.18.6`, energía generada `1.28.0` y `1.28.1…1.28.6`, potencia `0.17.0`/`0.24.0`, tensión `0.327.0` e intensidad `0.317.0`.

En **Ajustes → Protocolo** selecciona `DLMS/COSEM · ZIV 5CTB`. Los valores iniciales son cliente DLMS 16 y servidor 1. La clave solo es necesaria si la asociación del contador la exige.

La documentación pública de ZIV que se ha podido contrastar para esta familia confirma el uso de DLMS/COSEM en el puerto óptico y esos identificadores de medida en equipos ZIV; el modelo exacto 5CTB-3AB-M está homologado como contador trifásico bidireccional. El acceso real puede depender de la configuración de la distribuidora.

## Contadores con IEC 870-5-102 (p. ej. Circutor CIRWATT B, contadores de empresa)
Segundo protocolo, binario, del Reglamento de puntos de medida. Se elige en **Ajustes → Protocolo**.
1. En **Ajustes** elige *IEC 870-5-102* e introduce la **dirección del punto de medida** y la **clave de acceso** (las conoce quien gestiona la medida).
2. Si no sabes la **dirección de enlace**, ve a **Diagnóstico → Buscar dirección de enlace** (prueba 0–255 y 65535 con una petición de estado, de solo lectura; dura ~70 s). Si ya conoces la velocidad y el formato, ajústalos antes. **Diagnóstico 870-5-102** prueba velocidades (1200–19200) y formatos (8E1 / 8N1) y los guarda en Ajustes cuando el contador responde.
3. Pulsa **Consumo**, **FV** o **Todo** en la pestaña Lectura.

Secuencia que sigue: estado del enlace (`10 49 A A CS 16`) → reposición (`10 40 …`) → inicio de sesión con la clave (ASDU 183) → lectura de totales integrados absolutos (ASDU 122) con sondeo de clase 2 → fin de sesión (ASDU 187).

Qué devuelve: energía activa importada (→ `1.8.0`) y exportada (→ `2.8.0`) y reactiva por cuadrantes Q1–Q4 (→ `5.8.0`…`8.8.0`), con la hora del periodo cerrado. **No** da el desglose por periodos tarifarios P1–P6.

Limitaciones y avisos:
- Implementado a partir de la especificación publicada por Red Eléctrica y de una implementación de código abierto (gisce/iec870ree). **No se ha probado con un contador real**: puede necesitar ajustes en el primer intento.
- Con una clave incorrecta algunos contadores bloquean el acceso tras varios fallos. La app envía la clave una sola vez por lectura y el modo en vivo se detiene al primer fallo con este protocolo.
- Si el contador solo guarda totales tras un cierre, puede hacer falta un *cierre manual* en él. Prueba también el otro registro (curva de carga / resúmenes diarios).
- Las magnitudes se muestran tal como las entrega el contador; en medida indirecta (transformadores) puede haber que aplicar la relación de transformación.

## Importante: contadores en España
- Muchos contadores inteligentes de las distribuidoras (Iberdrola, Endesa, UFD, etc.) usan **DLMS/COSEM** en su puerto óptico, a menudo con acceso restringido o con contraseña. Esta app implementa el modo C de IEC 62056-21; si tu contador habla DLMS, mostrará «El contador no responde» o datos no reconocibles.
- Comprueba el modelo de tu contador y su documentación de puerto óptico antes de comprar la sonda.
- Si lees solo parte de los registros, pulsa **Todo** y abre «Ver valores OBIS» para ver qué códigos devuelve tu modelo; los nuevos se pueden clasificar en `ObisInfo.kt`.
- Usa solo el puerto óptico de **tu** contador y respeta el precinto: no lo manipules.

## Estructura
- `Iec62056.kt`: protocolo, BCC y parser OBIS (sin dependencias de Android).
- `MeterLink.kt`: secuencia de lectura sobre el puerto serie.
- `UsbConnector.kt`: detección de la sonda y permiso USB.
- `ReadingStore.kt`: histórico (CSV interno) y exportación.
- `Iec870.kt`: IEC 870-5-102 (tramas FT1.2, ASDU, etiquetas de tiempo; sin Android). `Meter102Link.kt`: sesión y lectura. `Diagnostics102.kt`: diagnóstico y búsqueda de dirección. `MeterConfig.kt`, `SettingsScreen.kt`: ajustes.
- `Diagnostics.kt`, `DiagnosticScreen.kt`, `ByteFormat.kt`: modo de diagnóstico.
- `Stats.kt`, `MeterModels.kt`, `MeterViewModel.kt`, `Ui.kt`, `MainActivity.kt`.

## Gradle incluido

El proyecto incluye `gradlew` y `gradlew.bat`. Usan Gradle **8.9**, el mismo que declara `gradle/wrapper/gradle-wrapper.properties`. Si no tienes Gradle instalado, el lanzador descarga automáticamente la distribución de Gradle 8.9 en `.gradle-local` la primera vez que lo ejecutes.

### Compilar desde Linux/macOS

```bash
./gradlew :app:assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Compilar desde Windows

```bat
gradlew.bat :app:assembleDebug
```

> La primera compilación necesita Internet para descargar Gradle y las dependencias Android/Kotlin/USB/DLMS. Después, Gradle utiliza su caché local.
