@echo off
setlocal EnableExtensions
set "ROOT_DIR=%~dp0"
set "DIST_VERSION=8.9"
set "DIST_DIR=%ROOT_DIR%.gradle-local\gradle-%DIST_VERSION%"
set "DIST_ZIP=%ROOT_DIR%.gradle-local\gradle-%DIST_VERSION%-bin.zip"
set "GRADLE_BIN=%DIST_DIR%\bin\gradle.bat"

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)

if not exist "%GRADLE_BIN%" (
  if not exist "%ROOT_DIR%.gradle-local" mkdir "%ROOT_DIR%.gradle-local"
  echo Gradle %DIST_VERSION% no esta instalado. Descargando...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%DIST_VERSION%-bin.zip' -OutFile '%DIST_ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ZIP%' '%ROOT_DIR%.gradle-local'"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
